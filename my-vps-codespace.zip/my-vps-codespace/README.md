# Ubuntu VPS Codespace

This repository sets up a mini Ubuntu VPS-like environment inside GitHub Codespaces.

## Features
- Ubuntu 22.04
- Root access
- Network tools: curl, wget, net-tools, iproute2
- Dev tools: git, vim, tmux, htop
- Python 3 and pip

## Usage
1. Open Codespace in GitHub.
2. The container will build automatically.
3. You have full terminal access to a mini VPS environment.
