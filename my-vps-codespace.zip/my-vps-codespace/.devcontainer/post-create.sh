#!/bin/bash
apt-get update && apt-get upgrade -y
apt-get install -y sudo curl wget vim git htop tmux net-tools iproute2 python3-pip
apt-get clean && rm -rf /var/lib/apt/lists/*
echo "Mini Ubuntu VPS ready!"
